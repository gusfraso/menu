//UPPGIFTEN: Gör en sida där du ser menyn på färdiga pizzor som du hämtar från API B, du ska bara visa menyn med pizzor. 
//Här finns ingen övrig funktionalitet. 
//API B: http://webbred2.utb.hb.se/~fewe/dynwebbvt20/api/api.php?data=menu





//fetch("http://webbred2.utb.hb.se/~fewe/dynwebbvt20/api/api.php?data=menu").then(function (resp) {
    //returnera resp i json_format

//}).then(function (menuData) {
    //anropa din funktion
 //   console.log(menuData);
//});

//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
//function showMenu(menuData) {
  //  var template = "";

    //TIPS:
    //1. skapa en variabel som du kallar template, din template ska läggas in i menu (som är ett id där alla dina pizzor ska synas). 
    //2. Loopa över menuData
    //använd ${} för att "spränga in data" istället för att konkatinera med + 
    //Du kan utgå från den här templaten inuti din första loop, men du får självklart gör din egen också:
    //   template +=  
    //      <div class="fh5co-item">
    //      <img src="${läggInBild}" class="img-responsive" alt="Bild på pizza">
    //     <h3>${läggInRubrik}</h3>
    //     <span class="fh5co-price">${läggInPris} kr</span>
    //     <p>Ingredienser: </p>`;
    //     for (din andra loop - LOOPA ÖVER CONTENT) {
    //         template += `<span> ${läggInContent} </span> `
    //     }
    //     template += `</div></div>`

 //   document.getElementById("menu").innerHTML = template;
//}
